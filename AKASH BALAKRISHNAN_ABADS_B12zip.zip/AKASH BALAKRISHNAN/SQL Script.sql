use fda_kaggle;

## TASK 1: IDENTIFYING APPROVAL TRENDS ##

## 1) To determine the number of drugs approved each year and provide insights into the yearly trends ##
SELECT * FROM regactiondate;
SELECT YEAR(ActionDate) AS ApprovalYear,COUNT(*) AS NumApprovedDrugs
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY ApprovalYear;

## 2) To identify the top thtree years that got the highest and lowest approvals in descending and ascending orders respectively
SELECT YEAR(ActionDate) AS ApprovalYear,COUNT(*) AS NumApprovedDrugs
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY NumApprovedDrugs DESC
LIMIT 3;

SELECT YEAR(ActionDate) AS ApprovalYear,COUNT(*) AS NumApprovedDrugs
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate)
ORDER BY NumApprovedDrugs ASC
LIMIT 3;

## 3) Explore approval trends over the years based on sponsors ##

UPDATE regactiondate
SET SponsorApplicant = (
SELECT SponsorApplicant
FROM application
WHERE application.ApplNo = regactiondate.ApplNo
);
SELECT YEAR (ActionDate) AS ApprovalYear,COUNT(*) AS NumApprovedDrugs,SponsorApplicant AS Sponsors
FROM regactiondate
WHERE ActionType = 'AP'
GROUP BY YEAR(ActionDate),(SponsorApplicant)
ORDER BY ApprovalYear,Sponsors;

## 4) Rank sponsors based on the total number of approvals they received each year between 1939 and 1960 ##

SELECT YEAR (ActionDate) AS ApprovalYear,COUNT(*) AS NumApprovedDrugs,SponsorApplicant AS Sponsors,
RANK() OVER (PARTITION BY YEAR(ActionDate) ORDER BY COUNT(*) DESC) AS SponsorRank
FROM regactiondate
WHERE YEAR(ActionDate) BETWEEN 1939 AND 1960
GROUP BY ApprovalYear,SponsorApplicant
ORDER BY ApprovalYear,SponsorRank;


## TASK 2 : Segmentation Analysis Based on Drug Marketing Status ##

## 1) Group products based on MarketingStatus. Provide meaningful insights into the segmentation patterns ##

ALTER TABLE product ADD COLUMN MarketingStatus VARCHAR(250);
 UPDATE product
 SET MarketingStatus = CASE
                        WHEN  ProductMktStatus = 1 THEN "Marketed"
                        WHEN  ProductMktStatus = 2 THEN "Withdrawn"
                        WHEN  ProductMktStatus = 3 THEN "Pending"
					    WHEN  ProductMktStatus = 4 THEN "Pre-Market"
					    ELSE  "NULL" 
 END ;
 SELECT MarketingStatus,COUNT(ProductNo) AS NumofProducts
 FROM product
 WHERE MarketingStatus IN ('Marketed','Withdrawn','Pending','Pre-Market')
 GROUP BY MarketingStatus;
 
## 2) Calculate the total number of applications for each MarketingStatus year-wise after the year 2010 ##


UPDATE regactiondate
JOIN product ON regactiondate.ApplNo = product.ApplNo
SET regactiondate.MarketingStatus = product.MarketingStatus;


SELECT YEAR(ActionDate) AS ApplicationYear,
           MarketingStatus,
           COUNT(ApplNo) AS num_applications
           FROM regactiondate
           WHERE YEAR(ActionDate)>2010
           GROUP BY ApplicationYear,MarketingStatus
           ORDER BY  ApplicationYear,MarketingStatus;

 ## Task 3: Analyzing Products
 
## 1) Categorize Products by dosage form and analyze their distribution

SELECT
    CONCACT_WS(' ',Form,Dosage) AS DosageForm,
    COUNT(*) AS ProductCount
FROM
  product
GROUP BY 
   DosageForm;


## 2) Calculate the total number of approvals for each dosage form and identify the most
successful forms.

SELECT
    CONCACT_WS(' ',Form,Dosage) AS DosageForm,
    COUNT(*) AS ProductCount
FROM
  product
GROUP BY 
   DosageForm
ORDER BY TotalApprovals DESC;

## 3) Investigate yearly trends related to successful forms ##
 

 SELECT YEAR(ActionDate) AS Submission_Year,
        COUNT(*) AS num_successful_forms
        FROM regactiondate
        WHERE ActionType = 'AP'
        GROUP BY Submission_Year
        ORDER BY Submission_Year;
 
 ##  Task 4: Exploring Therapeutic Classes and Approval Trends  ##
 
## 1) Analyze drug approvals based on therapeutic evaluation code (TE_Code) ##
 
 SELECT TECode,COUNT(*) AS num_drug_approvals
 FROM product_tecode
 GROUP BY TECode
 ORDER BY num_drug_approvals DESC;

## 2) Determine the therapeutic evaluation code (TE_Code) with the highest number of Approvals in each year ##
  
  WITH RankedApprovals AS (
       SELECT p.TECode,
			YEAR(r.ActionDate) AS ApprovalYear,
            COUNT(*) AS num_approvals,
            ROW_NUMBER() OVER (PARTITION BY YEAR(r.ActionDAte) ORDER BY COUNT(*) DESC) AS rn
  FROM regactiondate r
  JOIN product_tecode p ON r.ApplNo = p.ApplNo
  GROUP BY p.TECode, YEAR(r.ActionDate)
  )
  SELECT TECode, ApprovalYear,num_approvals
  FROM RankedApprovals
  WHERE rn = 1;
 
 





